#ifndef JBLOCK_H
#define JBLOCK_H
#include "grid.h"
class JBlock: public Grid {
	public:
		JBlock();

		void rotateClockwise() override;
		void rotateCounterClockwise() override;
};
#endif
