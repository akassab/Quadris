

#include "board.h"
#include "iblock.h"
#include "jblock.h"
#include "lblock.h"
using namespace std;
int main() {
	//Board *b = new Board();
	
	//b->addBlock('L', 5,5);
	//b->print();
	
	//		b->newBlock('L');
	//		b->print();
	Grid *b = new LBlock();
	b->printCurrent();
	string rotate;
	while (cin >> rotate) {
		if (rotate == "r") {
			b->rotateClockwise();
		}
		else if (rotate == "c") {
			b->rotateCounterClockwise();
		}
		b->printCurrent();
	}

	

}
	



