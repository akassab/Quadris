#ifndef LBLOCK
#define LBLOCK
#include "grid.h"
class LBlock: public Grid {
	public:
		LBlock();
		void rotateClockwise() override;
		void rotateCounterClockwise() override;
};
#endif
