
#include "board.h"

using namespace std;
Board::Board() {
	board.resize(22);
	for (int i = 0; i < 22; ++i) {
		board[i].resize(13);
	}
}

void Board::print() {
	for (int i = 0; i < 22; ++i) {
		if (i == 1) {
			cout << "-Level:    " << 1 << "-" << endl;
		}
		else if (i == 2) {
			cout << "-Score:    " << 0 << "-" << endl;
		}
		else if (i == 3) {
			cout << "-Hi Score  " << 0 << "-" << endl;
		}
		else {
			for (int c = 0; c < 13; ++c) {
				if (c == 0 || c == 12) {
					cout << "-";
				}
		
				else if (i == 4 || i == 0 || i == 21) {
					cout << "-";
				}
				else if (board[i][c].isL()) {
					cout << 'L';
				}
				else {
					cout << ' ';
				}
			}
		cout << endl;
		}
	}
}

void Board::newBlock(char type) {
	if (type == 'L') {

		board[5][5] = *(new Cell(type));
		board[6][5] = *(new Cell(type));
		board[6][6] = *(new Cell(type));
		board[6][7] = *(new Cell(type));
		board[6][7] = *(new Cell(type));
	}
}

void Board::clearNew() {
	for (int i = 0; i < 4; ++i) {
		for (int r = 0; r < 11; ++r) {
			board[i][r] = *(new Cell());
		}
	}
}
