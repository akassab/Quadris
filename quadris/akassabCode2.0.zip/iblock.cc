#include "iblock.h"
#include "grid.h"
IBlock::IBlock(): Grid{4} {
	for (int i = 0; i < 4; ++i) {
		possibilities[0][3][i] = *(new Cell('I'));
		possibilities[1][i][0] = *(new Cell('I'));
	}
	current = possibilities[pos];
}
	

void IBlock::rotateClockwise() {
	if (pos == 1) {
		pos = 0;
		current = possibilities[pos];
	}
	else {
		pos += 1;
		current = possibilities[pos];
	}
	
}

void IBlock::rotateCounterClockwise() {
	if (pos == 0) {
		pos = 1;
		current = possibilities[pos];
	}
	else {
		pos -= 1;
		current = possibilities[pos];
	}
}
	
