#ifndef GRID_H
#define GRID_H
#include <vector>
#include <iostream>
#include "cell.h"
class Grid {
	protected:
	int dim;
	int pos;
	std::vector<std::vector<Cell>> current;
	std::vector<std::vector<std::vector<Cell>>> possibilities;
	// initializes theGrid as a x*x 2D vector.
	public: 
		Grid(int x);
		// destroys the grid
		virtual void rotateClockwise() = 0;
		virtual void rotateCounterClockwise() = 0;
		std::vector<std::vector<Cell>> &getPossibility(int x);
		
		
		int getDim();
		void setPos(int x);
		int getPos();
		void printCurrent();
};
#endif
