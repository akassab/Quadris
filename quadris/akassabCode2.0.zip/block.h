class Board {
	vector<vector<Cell>> board;
	board
