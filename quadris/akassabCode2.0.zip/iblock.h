#ifndef IBLOCK_H
#define IBLOCK_H
#include "grid.h"
class IBlock: public Grid {
	public:
	IBlock();
	void rotateClockwise() override;
	void rotateCounterClockwise() override;
};
#endif
