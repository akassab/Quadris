#include "jblock.h"
#include "grid.h"

JBlock::JBlock(): Grid{3} {
	
	// j
	// j j j
	possibilities[0][1][0] = *(new Cell('J'));
	possibilities[1][0][1] = *(new Cell('J'));
	possibilities[2][2][2] = *(new Cell('J'));
	possibilities[3][2][0] = *(new Cell('J'));
	for (int i = 0; i < 3; ++i) {
		possibilities[0][2][i] = *(new Cell('J'));
		possibilities[1][i][0] = *(new Cell('J'));
		possibilities[2][1][i] = *(new Cell('J'));
		possibilities[3][i][1] = *(new Cell('J'));
	}
	current = possibilities[pos];
		 // 0 , 1 0
		// 0 ,1  , 1
		// 0 , 1 , 2
	// j j 
	// j
	// j
	
	//
	// j j j
	//     j

	//   j
	//   j
	// j j

		
}

void JBlock::rotateClockwise() {
	if (pos == 3) {
		pos = 0;
		current = possibilities[pos];
	}
	else {
		pos += 1;
		current = possibilities[pos];
	}
}


void JBlock::rotateCounterClockwise() {
	if (pos == 0) {
		pos = 3;
		current = possibilities[pos];
	}
	else {
		pos -= 1;
		current = possibilities[pos];
	}
}
