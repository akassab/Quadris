#ifndef BOARD_H
#define BOARD_H
#include <iostream>
#include <vector>
#include "cell.h"
using std::vector;
class Board { 
	vector<vector<Cell>> board;
	public:
	Board();
	void newBlock(char type);
	void draw();
	void print();
	void clearNew();
};
#endif
