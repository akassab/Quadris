#include "grid.h"
#include <vector>
using namespace std;
Grid::Grid(int x) {
	pos = 0;
	dim = x;
	possibilities.resize(5);
	for (int pos = 0; pos < 5; ++pos) {
		possibilities[pos].resize(dim);
		for (int row = 0; row < dim; ++row) {
			possibilities[pos][row].resize(dim);
			for (int col = 0; col < dim; ++col) {
				possibilities[pos][row][col] = *(new Cell('-'));
			}
		}
	}
}


vector<vector<Cell>> &Grid::getPossibility(int x) {
	return possibilities[x];
}








int Grid::getDim() {
	return dim;
}

void Grid::setPos(int x) {
	pos = x;
}

int Grid::getPos() {
	return pos;
}

void Grid::printCurrent() {
	for (int r = 0; r < dim; ++r) {
		for (int c = 0; c < dim; ++c) {
			cout << current[r][c].getType();
		}
		cout << endl;
	}
}
		
