#ifndef OBLOCK_H
#define OBLOCK_H
#include "grid.h"
class OBlock: public Grid {
	public:
		OBlock();
		
		void rotateClockwise() override;
		void rotateCounterClockwise() override;
};
#endif
