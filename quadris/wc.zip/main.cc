

#include "board.h"
#include "iblock.h"
#include "jblock.h"
#include "lblock.h"
#include "zblock.h"
#include "tblock.h"
#include "oblock.h"
#include "sblock.h"
using namespace std;
int main() {
	Board *board = new Board();
	
	

	
	//		b->newBlock('L');
	//		b->print();
	Block *b = new LBlock();
	board->newBlock(b);
	string rotate;
	while (cin >> rotate) {
		if (rotate == "l") {
			b = new LBlock();
			board->newBlock(b);
		}
		else if (rotate == "i") {
			b = new IBlock();
			board->newBlock(b);
		}
		else if (rotate == "o") {
			b = new OBlock();
			board->newBlock(b);
		}
		else if (rotate == "s") {
			b = new SBlock();
			board->newBlock(b);
		}
		else if (rotate == "z") {
			b = new ZBlock();
			board->newBlock(b);
		}
		else if (rotate == "j") {
			b = new JBlock();
			board->newBlock(b);
		}
		else if (rotate == "t") {
			b = new TBlock();
			board->newBlock(b);
		}
		else if (rotate == "r") {
			b->rotateClockwise();
		}
		else if (rotate == "c") {
			b->rotateCounterClockwise();
		}
		else if (rotate == "d") {

		}
		board->print();
		
	}

	

}
	



