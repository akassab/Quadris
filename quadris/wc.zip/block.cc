#include "block.h"
#include <vector>
using namespace std;
Block::Block(int gridDim, int numPossibilities) {
	pos = 0;
	dim = gridDim;
	possibilities.resize(numPossibilities);
	for (int pos = 0; pos < numPossibilities; ++pos) {
		possibilities[pos].resize(dim);
		for (int row = 0; row < dim; ++row) {
			possibilities[pos][row].resize(dim);
			for (int col = 0; col < dim; ++col) {
				possibilities[pos][row][col] = *(new Cell());
			}
		}
	}
}


vector<vector<Cell>> &Block::getPossibility(int x) {
	return possibilities[x];
}








int Block::getDim() {
	return dim;
}

void Block::setPos(int x) {
	pos = x;
}

int Block::getPos() {
	return pos;
}

void Block::printCurrent() {
	for (int r = 0; r < dim; ++r) {
		for (int c = 0; c < dim; ++c) {
			cout << current[r][c].getType();
		}
		cout << endl;
	}
}
		
