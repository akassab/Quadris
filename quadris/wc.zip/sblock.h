#ifndef SBLOCK_H
#define SBLOCK_H
#include "block.h"
class SBlock: public Block {
	public:
		SBlock();
		void rotateClockwise() override;
		void rotateCounterClockwise() override;
};
#endif
