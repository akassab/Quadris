#ifndef ZBLOCK_H
#define ZBLOCK_H
#include "block.h"
class ZBlock: public Block {
	public:
		ZBlock();
		void rotateClockwise() override;
		void rotateCounterClockwise() override;
};
#endif
