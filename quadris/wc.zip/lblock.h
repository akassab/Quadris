#ifndef LBLOCK
#define LBLOCK
#include "block.h"
class LBlock: public Block {
	public:
		LBlock();
		void rotateClockwise() override;
		void rotateCounterClockwise() override;
};
#endif
