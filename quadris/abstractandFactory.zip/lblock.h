#ifndef LBLOCK
#define LBLOCK
#include "block.h"
class LBlock: public Block {
	public:
		LBlock();
};
#endif
