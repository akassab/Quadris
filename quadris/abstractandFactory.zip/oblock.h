#ifndef OBLOCK_H
#define OBLOCK_H
#include "block.h"
class OBlock: public Block {
	public:
		OBlock();
};
#endif
