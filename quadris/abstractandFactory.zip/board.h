#ifndef BOARD_H
#define BOARD_H
#include <iostream>
#include <vector>
#include "cell.h"
#include "block.h"
using std::vector;
class Board { 
	vector<vector<Cell>> board;
	public:
	Block *current;
	Board();
	void newBlock(Block *b);
	void draw();
	void print();
	void clearNew();

};
#endif
